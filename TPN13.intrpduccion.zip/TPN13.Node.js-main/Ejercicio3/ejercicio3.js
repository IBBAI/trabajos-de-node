const os = require("os");

console.log(os.freemem());

let array = [];
for (let x = 0; x < 10000; x++) {
    array.push(1);
}
console.log(array);
console.log(os.freemem());