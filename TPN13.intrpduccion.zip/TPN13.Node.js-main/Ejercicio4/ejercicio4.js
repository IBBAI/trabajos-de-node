const fs = require("fs");

fs.writeFile("Ejercicio4/archivo1.txt", "línea 1 \n Línea 2", (error) => {
    if (error) console.log(error);
    else console.log("El archivo fue creado");
});

fs.readFile("./archivo1.txt", (error, datos) => {
    if (error) console.log(error);
    else console.log(datos.toString());
});

console.log("última línea del programa");